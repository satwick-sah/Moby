function calculateDueDate() {
  var startDate = document.getElementById("startDate").value;
  if (!startDate) {
    alert("Please enter the first day of your last menstrual period.");
    return;
  }

  var startDateObj = new Date(startDate);
  // Pregnancy is approximately 40 weeks
  var dueDate = addWeeks(startDateObj, 40);
  var resultText = "Your estimated due date is: " + dueDate.toDateString();
  document.getElementById("result").textContent = resultText;
}

function addWeeks(date, weeks) {
  date.setDate(date.getDate() + weeks * 7);
  return date;
}
