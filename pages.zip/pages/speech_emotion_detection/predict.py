from flask import Flask, request, jsonify
from tensorflow.keras.models import load_model
import numpy as np
import librosa
import os
import soundfile as sf

app = Flask(__name__)

# Load the saved model
model = load_model('saved_model.h5')

def preprocess_audio(file_path):
    # This function should match the preprocessing used during model training
    # Example: Load the file, extract features, and reshape for the model
    signal, sr = librosa.load(file_path, sr=22050)
    if len(signal) > 0:
        mfccs = librosa.feature.mfcc(y=signal, sr=sr, n_mfcc=40)
        mfccs_processed = np.mean(mfccs.T,axis=0)
    else:
        mfccs_processed = np.zeros(40)
    return mfccs_processed.reshape(1, -1)

@app.route('/predict', methods=['POST'])
def predict():
    # Obtain the file from the request
    file = request.files['audio_data']
    filename = os.path.join('uploads', file.filename)
    file.save(filename)
    
    # Preprocess the audio to the format your model expects
    features = preprocess_audio(filename)

    # Predict and return the result
    prediction = model.predict(features)
    predicted_class = np.argmax(prediction, axis=1)
    
    # Clean up the temporary file
    os.remove(filename)
    
    return jsonify({'prediction': str(predicted_class[0])})

if __name__ == '__main__':
    app.run(debug=True)
